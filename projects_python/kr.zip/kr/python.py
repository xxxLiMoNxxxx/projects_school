from cgitb import text
import tkinter as tk
from turtle import color

# 1 рівень
# 1 завдання
print("Основи програмування пайтону: 12") #я надіюсь тут не потрібен коментар)
# 2 завдання в іншому файлі (2ex)

# 3 завдання
while(True): #цикл
    playlist = [] #список
    playlist_input = input("Введіть назву трека: ") #прошу ввести назву трека
    playlist.append(playlist_input) #додаю до списка трек
    print(playlist) #вивожу трек
# 2 рівень
# 4 завдання в іншому файлі (4ex)
# 5 завдання в іншому файлі (5ex)
# 6 завдання в іншому файлі (6ex)
# 3 рівень
# 7 завдання в іншому файлі (7ex)
